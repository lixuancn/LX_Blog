<?php
echo '恭喜您安装成功<br><br>';

echo '感谢您使用LaneWeChat微信快速开发框架（PHP）<br><br>';

echo '本项目维护与GitHub，诚邀您贡献代码，让我们变得更加优雅<br><br>';

echo '<a href="http://www.lanecn.com/article/main/aid-65">手册地址，点击传送</a><br><br>';

echo '<a href="http://www.lanecn.com/">博客首页，点击传送</a><br><br>';

echo '博客部署于SAE，感谢SINA云！';

?>