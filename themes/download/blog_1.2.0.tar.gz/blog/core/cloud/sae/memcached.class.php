<?php
/**
 * Sae Memcached 封装类.
 * @author: LaoYang <weiming2@staff.sina.com.cn>
 * @date: 2012-1-17 
 * @version $Id: memcached.class.php 2 2013-06-05 10:21:56Z manling $
 */

class CloudMemcached {
	
	public static function init() {
		$mc = new Memcached();		
		return $mc;
	}
}
?>