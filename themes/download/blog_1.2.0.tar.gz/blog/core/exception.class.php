<?php
/**
 * 异常处理类.
 * @Created by Lane.
 * @Author: lane
 * @Mail lixuan868686@163.com
 * @Date: 14-1-10
 * @Time: 下午4:22
 */

class DBException extends Exception {
	
}

class IOException extends Exception {
	
}

class SystemException extends Exception {
	
}

?>