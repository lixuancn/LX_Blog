<?php
/**
 * 管理员管理
 * Created by Lane.
 * @Class Admin
 * @Author: lane
 * @Mail: lixuan868686@163.com
 * Blog http://www.lanecn.com
 */
class Index extends AdminController {
    /**
     * @descrpition 构造函数
     */
	public function __construct() {
        parent::__construct();
	}

    /**
     * @descrpition 首页
     */
    public function main(){

        View::showAdminTpl('index');
    }
}
?>