<div class="container">
    <footer class="footer">
        <p class="pull-right"><a href="#" rel="nofollow">回到顶端</a></p>
    </footer>
    <div class="row">
        <div class="text-center">©2014 <a href="http://www.lanecn.com">www.lanecn.com</a> , All rights reserved. Power By <a href="http://www.lanecn.com">Li Xuan</a>.</div>
    </div>
</div>
</body>
</html>


