<div class="container">
    <div class="jumbotron">
        <h1>Lane<small>Blog</small></h1>
        <p>蝼蚁虽小，也有梦想</p>
    </div>
</div>