<div class="container">
	<footer class="footer">
        <p class="pull-right"><a href="#" rel="nofollow">回到顶端</a></p>
    </footer>
    <div class="row">
        <div class="text-center">©2014 <a href="http://www.lanecn.com">www.lanecn.com</a> , All rights reserved. Power By <a href="http://www.lanecn.com">Li Xuan</a>.&nbsp;&nbsp;<a rel="nofollow" href="http://www.miitbeian.gov.cn/">京ICP备14005030号</a> <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_5824445'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s23.cnzz.com/stat.php%3Fid%3D5824445' type='text/javascript'%3E%3C/script%3E"));</script></div>
    </div>
</div>
</body>
</html>